# AI NPC Simulation 🎮

This project demonstrates **AI-powered NPC behavior simulation** using **Deep Reinforcement Learning**.

NPC adapts dynamically to player actions (`attack`, `defend`, `wait`) using a custom environment.

## 🚀 Features
- Custom **Gym Environment** (`npc_env.py`)
- Deep Q-Learning (DQN) with PyTorch
- NPC learns strategies to counter player moves
- Training progress visualized with reward plots

## 📂 Repo Structure
```
AI-NPC-Simulation-2/
├── npc_simulation.py    # Main training script
├── npc_env.py           # Custom NPC environment
├── requirements.txt     # Dependencies
├── models/              # Saved trained models
├── results/             # Training graphs
```

## ⚡ How to Run
```bash
# Install dependencies
pip install -r requirements.txt

# Run training
python npc_simulation.py
```

Results (reward graph) will be saved in `/results/training_rewards.png`.

## 📊 Example Output
- NPC starts random
- Learns over time to **counter player**
- Reward curve improves across episodes

---

👩‍💻 Developed by Rupali Tribhuvan  
