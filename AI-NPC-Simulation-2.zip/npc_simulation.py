import torch
import torch.nn as nn
import torch.optim as optim
import random
import numpy as np
import matplotlib.pyplot as plt
from collections import deque
from npc_env import NPCEnv

# DQN network
class DQN(nn.Module):
    def __init__(self, state_size, action_size):
        super(DQN, self).__init__()
        self.fc1 = nn.Linear(state_size, 24)
        self.fc2 = nn.Linear(24, 24)
        self.fc3 = nn.Linear(24, action_size)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)

# Hyperparameters
EPISODES = 300
GAMMA = 0.95
LR = 0.001
MEM_SIZE = 1000
BATCH_SIZE = 32

env = NPCEnv()
state_size = 1  # discrete encoded state
action_size = env.action_space.n

policy_net = DQN(state_size, action_size)
target_net = DQN(state_size, action_size)
target_net.load_state_dict(policy_net.state_dict())
optimizer = optim.Adam(policy_net.parameters(), lr=LR)

memory = deque(maxlen=MEM_SIZE)

def select_action(state, epsilon):
    if random.random() < epsilon:
        return random.randrange(action_size)
    state = torch.tensor([[state]], dtype=torch.float32)
    with torch.no_grad():
        return policy_net(state).argmax().item()

def replay():
    if len(memory) < BATCH_SIZE:
        return
    batch = random.sample(memory, BATCH_SIZE)
    states, actions, rewards, next_states = zip(*batch)

    states = torch.tensor(states, dtype=torch.float32).unsqueeze(1)
    actions = torch.tensor(actions, dtype=torch.int64).unsqueeze(1)
    rewards = torch.tensor(rewards, dtype=torch.float32).unsqueeze(1)
    next_states = torch.tensor(next_states, dtype=torch.float32).unsqueeze(1)

    q_values = policy_net(states).gather(1, actions)
    next_q_values = target_net(next_states).max(1)[0].detach().unsqueeze(1)
    targets = rewards + GAMMA * next_q_values

    loss = nn.MSELoss()(q_values, targets)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

rewards_all = []
epsilon = 1.0

for episode in range(EPISODES):
    state = env.reset()
    total_reward = 0

    for t in range(20):  # steps per episode
        action = select_action(state, epsilon)
        next_state, reward, done, _ = env.step(action)
        memory.append((state, action, reward, next_state))
        state = next_state
        total_reward += reward
        replay()

    rewards_all.append(total_reward)
    epsilon = max(0.01, epsilon * 0.995)

    if episode % 20 == 0:
        target_net.load_state_dict(policy_net.state_dict())
        print(f"Episode {episode}, Total Reward: {total_reward}")

# Save model
torch.save(policy_net.state_dict(), "models/npc_model.pth")

# Plot rewards
plt.plot(rewards_all)
plt.xlabel("Episode")
plt.ylabel("Total Reward")
plt.title("NPC Learning Progress")
plt.savefig("results/training_rewards.png")
