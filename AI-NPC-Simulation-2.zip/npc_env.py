import numpy as np
import gym
from gym import spaces

class NPCEnv(gym.Env):
    def __init__(self):
        super(NPCEnv, self).__init__()
        # Actions: 0 = attack, 1 = defend, 2 = wait
        self.action_space = spaces.Discrete(3)
        # State: NPC last action, Player last action
        self.observation_space = spaces.Discrete(3*3)
        self.state = (0, 0)

    def step(self, action):
        npc_action = action
        player_action = np.random.choice([0,1,2])  # random player

        reward = 0
        # simple rule: counter player
        if npc_action == 0 and player_action == 2:  # attack vs wait
            reward = 1
        elif npc_action == 1 and player_action == 0:  # defend vs attack
            reward = 1
        elif npc_action == 2 and player_action == 1:  # wait vs defend
            reward = 1
        else:
            reward = -1

        self.state = (npc_action, player_action)
        done = False
        return self._get_obs(), reward, done, {}

    def reset(self):
        self.state = (0, 0)
        return self._get_obs()

    def _get_obs(self):
        return self.state[0] * 3 + self.state[1]

    def render(self, mode="human"):
        print(f"NPC: {self.state[0]}, Player: {self.state[1]}")
